#!/usr/bin/python
#Zoltan Szeleczki, 2018
import os
import lcddriver
import urllib
from time import sleep
urltotest='http://www.google.com'
nboftrials=0
answer='NO'
lcd = lcddriver.lcd()

while answer=='NO':
    try:
        urllib.urlopen(urltotest)
        answer='YES'
    except:
        lcd.lcd_display_string("     NO INTERNET    ",2)
        answer='NO'
        sleep(3)
        lcd.lcd_display_string("                    ",2)



