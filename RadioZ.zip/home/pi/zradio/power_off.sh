#!/bin/sh
#   Exports pin to userspace
sudo echo "15" > /sys/class/gpio/export

# Sets pin 10 GPIO15  as an output
sudo echo "out" > /sys/class/gpio/gpio15/direction

# Sets pin 10 GPIO15  to ...
sudo echo "0" > /sys/class/gpio/gpio15/value
