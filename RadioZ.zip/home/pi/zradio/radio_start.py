#!/usr/bin/env python
# -*- coding: utf-8 -*-

# zradio :Zoltan Szeleczki 2018
# rotary encoder handling parts of code from Bob Rathbone , Site : http://www.bobrathbone.com
#

import textwrap     #mpc out wrapping
import sys
import time
from rotary_class import RotaryEncoder
import os
from subprocess import check_output # to catch mpc's output
import lcddriver
import subprocess #bkg proce
from datetime import datetime

import unicodedata

def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD', input_str)
    return u"".join([c for c in nfkd_form if not unicodedata.combining(c)])

encoding = "utf-8"

#------------------------WIFI SETUP REFRESHING
os.system("/home/pi/zradio/rfshwifipw.py")

#------------------------CHANNEL REFRESHING
os.system("/home/pi/zradio/rfshstations.py")

#-----------------------CHECK INTERNET CONNECTION
os.system("/home/pi/zradio/checkNet.py")

#----------------------- END OF CHANNEL REFRESHING
LCDlogo1 = "      Radio PI"
LCDlogo2 = "            ,  "
LCDlogo3 = "    LEGYEN TANC"
LCDlogo4 = "         BYE"
zradiopath = "/home/pi/zradio"
channelmax = 0
channelmin = 0
stationfile = '/home/pi/zradio/stationlist.csv'
channelnames = []
lockchange = 0
mpcplaylistid = 0
LCDlastrfshts   = datetime.now()
LCDrfshfreq     = 3 #sec
LCDln      = 1
linelist  = ["","","",""]

lcd = lcddriver.lcd()

# show boot logo
lcd.lcd_display_string(LCDlogo2,2)
lcd.lcd_display_string(LCDlogo3,3)
LCDlastrfshts   = datetime.now()
time.sleep(1)

#-------- Load radio names
with open(stationfile) as f:
    stations = f.read().splitlines()
    for stationlistitem in stations:
	channellistline = [x.strip() for x in stationlistitem.split(';')]
	channelnames.append(channellistline[0])
	#channelurls.append(channellistline[1])
    channelmax = len(channelnames)-1 # 0..nth-1
# print channelnames[:]
# print "read channelnames, length:"
# print len(channelnames)

#start mpc & get back channel no#
mpcoutput      = check_output(["/usr/bin/mpc", "play"])
mpcoutput      = remove_accents(mpcoutput.decode(encoding))
mpcoutputlines = [x.strip() for x in mpcoutput.split('\n')]
mpcout2ndlineitems = [x.strip() for x in mpcoutputlines[1].split(' ')]
#print "1st mpc start gets last channel"
#print mpcout2ndlineitems[1]
currplaystring = [x.strip('#') for x in mpcout2ndlineitems[1].split('/')]
#print "last channel:"
#print currplaystring[0]

#---------start radio button and menu handler here
channel = int(currplaystring[0])-1  #continue from last playing playlist position
#prevchannel = channel
#mpcplaylistid = channel + 1 #'cos it starts from 1
#os.system("/usr/bin/mpc play %d" % channel)

mpcplaylistid = channel + 1 #'cos it starts from 1
#os.system("/usr/bin/mpc play %d" % mpcplaylistid)
#os.system("/usr/bin/mpc stop")

line  = ""
trial = 0
while line == "":
    line = check_output(["/usr/bin/mpc", "current"])
    # print ("start radio w/ %s" % (line))
    if line == "":
	#print ("trial %d" % (trial))
	os.system("/usr/bin/mpc play %d" % mpcplaylistid)
	time.sleep(3)
	trial += 1
    if trial == 10:
	line = "x" #to break loop

#print ("mpc started channel %d" % (mpcplaylistid))
# Define GPIO inputs
PIN_A = 24 # Pin 18 GPIO24
PIN_B = 25 # Pin 22 GPIO25
BUTTON = 15  # Pin 10 GPIO15
BUTTON2 = 23 # PIN 16 GPIO23
# This is the event callback routine to handle events
def switch_event(event):
	global channel
	global channelmax
	global channelmin
	#global prevchannel
	global lockchange
	if event == RotaryEncoder.CLOCKWISE and lockchange == 0:
		lockchange = 1
		channel += 1
		if channel > channelmax :
			channel = channelmax
	elif event == RotaryEncoder.ANTICLOCKWISE and lockchange == 0:
		lockchange = 1
		channel -= 1
		if channel < channelmin:
			channel = channelmin
	elif event == RotaryEncoder.BUTTONDOWN and lockchange == 0:
		#os.system("echo  '1:5:                    {eol}2:5: shutting down{eol}3:5:                    {eol}4:5:                    {eol}' > /tmp/LCDout2.fifo")
		lcd.lcd_clear()
#		lcd.lcd_display_string(LCDlogo4,3)
		LCDlastrfshts   = datetime.now()
#		time.sleep(1)
		os.system("/usr/bin/mpc stop >/dev/null")
		#GPIO.cleanup()
		os.system("sudo shutdown -h now")
	elif event == RotaryEncoder.BUTTON2DOWN and lockchange == 0:
		#print "button2 pressed"
		os.system("/usr/bin/mpc toggle >/dev/null")
		time.sleep(0.5)
	return
# Define the switch
rswitch = RotaryEncoder(PIN_A,PIN_B,BUTTON,BUTTON2,switch_event)
while True:
	#---------------------------------------------
	if lockchange == 1:
		mpcplaylistid = channel + 1 #'cos it starts from 1
		#send wait to LCD refresher
		###########################
		if (channel > channelmin):
		    line1 = channelnames[channel-1].ljust(16)
		    lcd.lcd_display_string(" "+str(mpcplaylistid-1).ljust(2)+" "+line1[0:16],1)
		else:
		    lcd.lcd_display_string("                    ",1)
		line2 = channelnames[channel].ljust(16)
		lcd.lcd_display_string(">"+str(mpcplaylistid).ljust(2)+" "+line2[0:16],2)
		if (channel < channelmax):
		    line3 = channelnames[channel+1].ljust(16)
		    lcd.lcd_display_string(" "+str(mpcplaylistid+1).ljust(2)+" "+line3[0:16],3)
		else:
		    lcd.lcd_display_string("                    ",3)
		lcd.lcd_display_string(LCDlogo1.ljust(20),4)
		os.system("/usr/bin/mpc play %d >/dev/null" % mpcplaylistid)
		#prevchannel = channel
		LCDlastrfshts = datetime.now() # keeps selection for some secs
		#---------------------------------------------
		time.sleep(0.1) # to prevent 100% cpu utilization
		#---------------------------------------------
		lockchange  = 0
	elif (datetime.now()-LCDlastrfshts).seconds >= LCDrfshfreq:
	    linelist=[]
	    line = check_output(["/usr/bin/mpc", "current"])
	    line = remove_accents(line.decode(encoding))
	    #mpc output's 1st line splitted by 2 parts. before separator is it the name of radio
	    #2nd part is content info
	    hdrlist  = [x.strip() for x in line.split(":",1)] #str.split([sep[, maxsplit]])
	    LCDln=1
	    #loop on 1st and 2nd part of mpc output
	    for hdrlistitem in hdrlist:
		x=hdrlistitem
		if x==hdrlist[0]:
		    line1=x[0:20]
		    #linelist = [x]
		    #print linelist
		else:
		    lines = (textwrap.fill(x, 20)) # mpc output is text wrapped
		    linelist  = [x.strip() for x in lines.split('\n')] #converted to list
	    linelist.insert(0,line1)
	    for i in range(len(linelist),4): #1st plus 3 lines
		linelist.append("")
		#print linelist
	    for oneline in linelist:   #one line of either 1st or 2nd part
		if LCDln <= 4:
		    #print oneline
		    if LCDln == 4 and oneline.strip() == "" :
			oneline  = LCDlogo1
		    lcd.lcd_display_string(oneline.ljust(20),LCDln) #extend to length 20 b
		    LCDlastrfshts = datetime.now()
		    LCDln += 1
	else:
	    #---------------------------------------------
	    time.sleep(0.2) # to prevent 100% cpu utilization
	    #---------------------------------------------
