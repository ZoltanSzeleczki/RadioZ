#!/usr/bin/python
import RPi.GPIO as GPIO ## Import GPIO Library
import lcddriver
import time
# lcd start
#print  "gpio 10 -> false  started"
lcd = lcddriver.lcd()

# this command clears the display (captain obvious)
lcd.lcd_clear()

# now we can display some characters (text, line)
lcd.lcd_display_string("        BYE",3)
#time.sleep(2)
#lcd.lcd_clear()

#GPIO.cleanup()
GPIO.setmode(GPIO.BOARD) ## Use BOARD pin numbering
GPIO.setup(10, GPIO.OUT) ## Setup GPIO15  OUT
GPIO.output(10,False) ## Turn off GPIO15 
#while True:
#    time.sleep(1)
#print  "gpio 10 -> false  finished"

