#!/usr/bin/python
#Zoltan Szeleczki, 2018
import os
import lcddriver
import subprocess #bkg process
from subprocess import check_output # to catch mpc's output
import time
#import mpd
#import sys


#user must change this file to upload new stations by vhangig the file on win partition
#line format:    name;url
stationfile = '/boot/stationlist.csv'  #file on windows partition, <-CHANGE THIS file only

#radio uses own copy of the file to show names in menu
#and to check that mpc playlist needs to be represhed or not
#if the file is not the same on  SD card's windows partition and on linox side
#this code below will refresh the own copy and mpc playlist as well. 
currstationfile = '/home/pi/zradio/stationlist.csv' #<- never change rhis file

numofchread = 0
errfound = 0
err = ""

with open(stationfile) as f1:
    stations = f1.read().splitlines()

with open(currstationfile) as f2:
    currstations = f2.read().splitlines()

if (stations != currstations):
#if (stations == currstations):   #for test
    lcd = lcddriver.lcd()
    lcd.lcd_clear()
    lcd.lcd_display_string("station list loading",1)
    time.sleep(1)
    os.system("mpc clear") # clear all stations
    for stationlistitem in stations:
	numofchread += 1
	linelist = [x.strip() for x in stationlistitem.split(';')] #converted to list
	#os.system("mpc add %s" % linelist[1])
	url = linelist[1]
	err = subprocess.check_output(["mpc","add",url])
	#print err
	#lcd.lcd_display_string("error in line: %d " % numofchread,2)
	#time.sleep(5)
	#errfound = 1
	#numofchread += 1 #it is a linecounter as well
	#if errfound == 1:
	#lcd.lcd_display_string("fix it or restore",3)
	#lcd.lcd_display_string("original file",4)
	#time.sleep(10)
	#print "x" #return error sign
	#else:
    os.system("sudo cp %s %s" % (stationfile,currstationfile))
    lcd.lcd_display_string("                    ",1)
    lcd.lcd_display_string("%d stations found " % numofchread,2)
    lcd.lcd_display_string("                    ",3)
    lcd.lcd_display_string("starting radio",4)
    time.sleep(5)
    #print numofchread #return number of channels
