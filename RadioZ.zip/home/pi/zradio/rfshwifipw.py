#!/usr/bin/python
#Zoltan Szeleczki, 2018
import os
import lcddriver
import subprocess #bkg process
from subprocess import check_output # to catch mpc's output
import time


#user must change this file to upload new stations by vhangig the file on win partition
 
usersetupfile = '/boot/wifi.conf'  #file on windows partition, <-CHANGE THIS file only
origconffile  = '/home/pi/zradio/wpa_supplicant.conf.orig' #master backup file, do not modify!

#radio uses own copy of the file to show names in menu
#and to check that config needs to be represhed or not
#if the file is not the same on  SD card's windows partition and on linox side
#this code below will refresh the own copy and wifi configuraiton as well. 
currsetupfile = '/home/pi/zradio/wpa_supplicant.conf' #<- never change rhis file
systemsetupfile =  '/etc/wpa_supplicant/wpa_supplicant.conf' #<- never change rhis file

numoflnread = 0
errfound = 0
err = ""

with open(usersetupfile) as f1:
    userlines = f1.read().splitlines()

with open(currsetupfile) as f2:
    currlines = f2.read().splitlines()

if (userlines != currlines):
    lcd = lcddriver.lcd()
    lcd.lcd_clear()
    lcd.lcd_display_string("wifi setup loading  ",1)
    time.sleep(1)
    os.system("sudo cp %s %s" % (usersetupfile,currsetupfile))
    os.system("sudo cp %s %s" % (usersetupfile,systemsetupfile))
    lcd.lcd_display_string("wifi setup changed  ",2)
    lcd.lcd_display_string("please restart      ",3)
    time.sleep(1)

